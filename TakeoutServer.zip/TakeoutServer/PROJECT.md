# 美味达外卖平台 - 完整项目说明

一个完整的端到端外卖平台：Android 端 + Python Flask 后端 + SQLite 数据库 + AI 推荐。

## 📁 项目结构

```
D:\ccworkspace\
├── Android\              # Android 端（登录 + 首页 + 购物车 + 下单）
└── TakeoutServer\        # Python Flask 后端
    ├── app.py            # 主程序
    ├── db.py             # 数据库 + 演示数据
    ├── ai_recommend.py   # AI 推荐引擎
    ├── requirements.txt  # Python 依赖
    └── takeout.db        # SQLite 数据库（自动生成）
```

## 🚀 完整启动流程

### 1️⃣ 启动后端（端口 5000）

```bash
cd D:\ccworkspace\TakeoutServer
pip install -r requirements.txt     # 首次
python app.py
```

看到以下输出表示成功：
```
==================================================
[Takeout] 美味达外卖平台 - 后端启动
==================================================
API 地址: http://127.0.0.1:5000
模拟器访问: http://10.0.2.2:5000
测试账号: test@test.com / 123456
==================================================
 * Running on http://127.0.0.1:5000
```

### 2️⃣ 启动 Android 端

1. 用 Android Studio 打开 `D:\ccworkspace\Android`
2. 等 Gradle Sync 完成
3. 点 **Run ▶️** 运行到模拟器或真机

### 3️⃣ 测试账号

| 账号 | 密码 |
|------|------|
| `test@test.com` | `123456` |
| `13800138000` | `123456` |
| `admin` | `admin` |

---

## 🎯 功能清单

### 后端 API（共 11 个）

| 接口 | 方法 | 路径 | 说明 |
|------|------|------|------|
| 登录 | POST | `/api/login` | 返回 token + 用户信息 |
| 注册 | POST | `/api/register` | |
| 轮播图 | GET | `/api/banners` | 4 张 banner |
| 分类 | GET | `/api/categories` | 8 个分类 |
| 菜品 | GET | `/api/foods` | 22 道菜，支持 `category_id`/`keyword`/`recommend` |
| 菜品详情 | GET | `/api/foods/<id>` | |
| **AI 推荐** | GET | `/api/recommend` | 基于时段 + 用户历史的智能推荐 |
| 地址列表 | GET | `/api/addresses` | |
| 新增地址 | POST | `/api/addresses` | |
| 创建订单 | POST | `/api/orders` | 含销量更新 + 历史记录 |
| 订单列表 | GET | `/api/orders` | |

### Android 端页面（共 8 个）

| 页面 | 功能 |
|------|------|
| MainActivity | 登录页（外卖风格 UI） |
| HomeActivity | 外卖首页（轮播图 + 分类 + AI 推荐 + 全部菜品 + 购物车栏） |
| CartActivity | 购物车（增减、清空、合计） |
| AddressListActivity | 收货地址列表 |
| AddressEditActivity | 新增地址 |
| PaymentActivity | 订单确认（地址 + 商品 + 价格 + 支付方式） |
| OrderSuccessActivity | 下单成功页 |
| OrderListActivity | 我的订单 |

---

## 🤖 AI 推荐策略

推荐引擎综合 5 个维度打分：

1. **时段匹配**（+30 分）
   - 早餐 06-10：轻食、饮品
   - 午餐 11-13：快餐、主食
   - 下午茶 14-17：甜品、奶茶
   - 晚餐 18-21：正餐
   - 夜宵 22-05：夜宵小吃

2. **用户偏好分类**（+40 分）
   - 基于购买历史频次最高的分类

3. **是否招牌推荐**（+15 分）

4. **销量加权**（每 200 销量 +1 分，上限 20）

5. **评分加权**（高于 4.0 每加 0.1 +1 分）

返回前 6 个 + 个性化推荐理由（如"晚餐已为您准备好，根据您的口味推荐【奶茶饮品】系列"）。

---

## 🎨 UI 设计风格

外卖风格暖色调（参考美团/饿了么）：
- 主色：橙色 `#FF5722`
- 辅色：黄色 `#FFC107`
- 背景：暖白 `#FFF8F5`
- 卡片：白色 + 圆角 24dp + 阴影
- 按钮：橙色渐变 + 圆角 28dp

---

## ⚠️ 注意事项

### Android 端连接后端

`ApiService.java` 中的 `BASE_URL` 默认是：

```java
private static final String BASE_URL = "http://10.0.2.2:5000";
```

- ✅ **模拟器**：直接用 `10.0.2.2` 即可访问宿主机
- ⚠️ **真机**：必须改成电脑的内网 IP，例如 `http://192.168.1.100:5000`
  - 查看方式：`ipconfig` 看 "无线局域网适配器 WLAN" 下的 IPv4 地址

### 网络权限

`AndroidManifest.xml` 已添加：
```xml
<uses-permission android:name="android.permission.INTERNET" />
<application android:usesCleartextTraffic="true" ...>
```

`usesCleartextTraffic` 必须开（因为后端是 HTTP 不是 HTTPS）。

### 重置数据库

删除 `takeout.db` 后重启 `app.py` 即可重新生成。

---

## 🛠️ 技术栈

### 后端
- Python 3.12
- Flask 3.0
- SQLite 3
- flask-cors（跨域支持）

### Android
- Java 17
- Android SDK 34
- Android Gradle Plugin 8.1
- Material Components
- OkHttp 4.12（网络）
- Gson 2.10（JSON）
- Glide 4.16（图片）
- ViewPager2（轮播图）
- RecyclerView（列表）

---

## 🔄 完整业务流程

```
登录页 (MainActivity)
    │
    │ 1. 输入账号密码
    │ 2. POST /api/login → 获取 token
    │ 3. 保存到 SharedPreferences
    ↓
首页 (HomeActivity)
    │
    │ • 顶部：配送地址 + 订单入口 + 退出
    │ • 轮播图：ViewPager2 + 3.5s 自动滚动
    │ • 分类：8 个 emoji 圆形入口
    │ • AI 推荐：根据时段+历史推荐
    │ • 全部菜品：22 道菜 + 加/减按钮
    │ • 底部：购物车栏（数量/总价/配送费）
    ↓
点击「去结算」或购物车图标
    ↓
购物车页 (CartActivity)
    │
    │ • 商品列表 + 增减
    │ • 清空购物车
    │ • 合计 + 配送费
    ↓
选地址下单
    ↓
地址列表 (AddressListActivity)
    │
    │ • 查看已有地址
    │ • 点击新增 → AddressEditActivity
    │ • 选择地址 → 进入支付
    ↓
订单确认 (PaymentActivity)
    │
    │ • 收货地址
    │ • 商品清单
    │ • 价格明细（商品 + 配送费）
    │ • 支付方式（微信/支付宝/银行卡）
    │ • 备注
    │ • POST /api/orders
    ↓
下单成功 (OrderSuccessActivity)
    │
    │ • 订单号 + 实付金额
    │ • 查看订单 / 返回首页
    ↓
返回首页 / 查看订单列表
```

---

## 🧪 测试命令（curl）

```bash
# 健康检查
curl http://127.0.0.1:5000/api/health

# 登录
curl -X POST http://127.0.0.1:5000/api/login \
  -H "Content-Type: application/json" \
  -d '{"username":"test@test.com","password":"123456"}'

# 用上一步返回的 token 调其他接口
TOKEN="..."
curl http://127.0.0.1:5000/api/recommend -H "Authorization: Bearer $TOKEN"

# 菜品（推荐）
curl "http://127.0.0.1:5000/api/foods?recommend=1"

# 分类
curl http://127.0.0.1:5000/api/categories
```

---

## 🐛 常见问题

### Q: Android 端报「网络错误」
- 检查后端是否启动（`curl http://127.0.0.1:5000/api/health`）
- 检查 `BASE_URL` 是否正确（模拟器 `10.0.2.2`，真机用电脑 IP）
- 真机要和电脑连同一 WiFi

### Q: Gradle 同步失败
- 确保网络能访问 Google Maven（可配代理或换国内镜像）
- 文件 → Invalidate Caches / Restart

### Q: 端口 5000 被占用
- 改 `app.py` 最后一行的 `port=5000` 为其他端口
- 同时改 Android `ApiService.java` 的 `BASE_URL`

### Q: 模拟器看不到轮播图
- 等几秒，banner 是异步加载
- 检查 Logcat 是否有错误

---

**最后更新**：2026-06-02
