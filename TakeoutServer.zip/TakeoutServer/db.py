"""
数据库初始化与连接管理
使用 SQLite，单文件数据库 takeout.db
"""
import sqlite3
import os
from contextlib import contextmanager

DB_PATH = os.path.join(os.path.dirname(__file__), "takeout.db")


def get_connection():
    """获取数据库连接（启用外键、行工厂）"""
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA foreign_keys = ON")
    return conn


@contextmanager
def get_db():
    """上下文管理器：自动提交与关闭"""
    conn = get_connection()
    try:
        cur = conn.cursor()
        yield cur
        conn.commit()
    except Exception:
        conn.rollback()
        raise
    finally:
        conn.close()


def init_db():
    """初始化所有表"""
    with get_db() as cur:
        # 用户表
        cur.execute("""
            CREATE TABLE IF NOT EXISTS users (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                username TEXT UNIQUE NOT NULL,
                password TEXT NOT NULL,
                nickname TEXT,
                phone TEXT,
                created_at TEXT DEFAULT CURRENT_TIMESTAMP
            )
        """)

        # 轮播图表
        cur.execute("""
            CREATE TABLE IF NOT EXISTS banners (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                title TEXT NOT NULL,
                image TEXT NOT NULL,
                link TEXT,
                sort_order INTEGER DEFAULT 0
            )
        """)

        # 分类表
        cur.execute("""
            CREATE TABLE IF NOT EXISTS categories (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                name TEXT NOT NULL,
                icon TEXT NOT NULL,
                sort_order INTEGER DEFAULT 0
            )
        """)

        # 菜品表
        cur.execute("""
            CREATE TABLE IF NOT EXISTS foods (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                name TEXT NOT NULL,
                description TEXT,
                price REAL NOT NULL,
                original_price REAL,
                image TEXT,
                category_id INTEGER NOT NULL,
                sales INTEGER DEFAULT 0,
                rating REAL DEFAULT 4.8,
                tags TEXT,
                is_recommend INTEGER DEFAULT 0,
                FOREIGN KEY (category_id) REFERENCES categories(id)
            )
        """)

        # 收货地址表
        cur.execute("""
            CREATE TABLE IF NOT EXISTS addresses (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                user_id INTEGER NOT NULL,
                receiver TEXT NOT NULL,
                phone TEXT NOT NULL,
                province TEXT,
                city TEXT,
                district TEXT,
                detail TEXT NOT NULL,
                is_default INTEGER DEFAULT 0,
                FOREIGN KEY (user_id) REFERENCES users(id)
            )
        """)

        # 订单表
        cur.execute("""
            CREATE TABLE IF NOT EXISTS orders (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                order_no TEXT UNIQUE NOT NULL,
                user_id INTEGER NOT NULL,
                address_id INTEGER,
                total_price REAL NOT NULL,
                status TEXT DEFAULT 'pending',
                payment_method TEXT,
                remark TEXT,
                created_at TEXT DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (user_id) REFERENCES users(id)
            )
        """)

        # 订单详情表
        cur.execute("""
            CREATE TABLE IF NOT EXISTS order_items (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                order_id INTEGER NOT NULL,
                food_id INTEGER NOT NULL,
                name TEXT NOT NULL,
                price REAL NOT NULL,
                quantity INTEGER NOT NULL,
                FOREIGN KEY (order_id) REFERENCES orders(id) ON DELETE CASCADE,
                FOREIGN KEY (food_id) REFERENCES foods(id)
            )
        """)

        # 用户浏览/购买历史（用于 AI 推荐）
        cur.execute("""
            CREATE TABLE IF NOT EXISTS user_history (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                user_id INTEGER NOT NULL,
                food_id INTEGER NOT NULL,
                action TEXT NOT NULL,
                created_at TEXT DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (user_id) REFERENCES users(id),
                FOREIGN KEY (food_id) REFERENCES foods(id)
            )
        """)


def seed_data():
    """插入演示数据（仅在表为空时插入）"""
    with get_db() as cur:
        # 检查是否已有数据
        cur.execute("SELECT COUNT(*) as c FROM categories")
        if cur.fetchone()["c"] > 0:
            return

        # 用户（密码明文，仅用于演示）
        cur.executemany(
            "INSERT INTO users (username, password, nickname, phone) VALUES (?, ?, ?, ?)",
            [
                ("test@test.com", "123456", "测试用户", "13800138000"),
                ("13800138000", "123456", "吃货小王", "13800138001"),
                ("admin", "admin", "管理员", "13800138002"),
            ],
        )

        # 轮播图
        cur.executemany(
            "INSERT INTO banners (title, image, link, sort_order) VALUES (?, ?, ?, ?)",
            [
                ("新店开业 全场5折", "https://images.unsplash.com/photo-1568901346375-23c9450c58cd?w=1200&h=600&fit=crop", "promo_new", 1),
                ("满 50 减 20 元", "https://images.unsplash.com/photo-1565299624946-b28f40a0ae38?w=1200&h=600&fit=crop", "promo_full", 2),
                ("会员日 免配送费", "https://images.unsplash.com/photo-1579871494447-9811cf80d66c?w=1200&h=600&fit=crop", "promo_vip", 3),
                ("夜宵专享 立减 10", "https://images.unsplash.com/photo-1555939594-58d7cb561ad1?w=1200&h=600&fit=crop", "promo_night", 4),
            ],
        )

        # 分类
        categories = [
            ("热卖推荐", "🔥", 1),
            ("汉堡披萨", "🍔", 2),
            ("日韩料理", "🍣", 3),
            ("中式快餐", "🍚", 4),
            ("奶茶饮品", "🧋", 5),
            ("甜品蛋糕", "🍰", 6),
            ("夜宵小吃", "🍢", 7),
            ("水果沙拉", "🍎", 8),
        ]
        cur.executemany(
            "INSERT INTO categories (name, icon, sort_order) VALUES (?, ?, ?)",
            categories,
        )

        # 菜品
        foods = [
            # 热卖推荐 (category_id=1)
            ("招牌香辣鸡腿堡", "现炸酥脆，秘制辣酱", 18.8, 25.0, "🍔", 1, 2580, 4.9, "招牌,辣", 1),
            ("超级至尊披萨", "9寸手抛薄底，芝士满满", 39.9, 58.0, "🍕", 1, 1230, 4.8, "芝士,招牌", 1),
            ("蜜汁烤鸡翅(3只)", "香甜蜜汁，外焦里嫩", 15.9, 22.0, "🍗", 1, 980, 4.7, "甜,招牌", 1),

            # 汉堡披萨 (category_id=2)
            ("双层牛肉芝士堡", "100%纯牛肉饼，双层享受", 25.9, 32.0, "🍔", 2, 856, 4.8, "芝士", 0),
            ("培根菠萝披萨", "咸甜搭配，热带风情", 35.0, 48.0, "🍕", 2, 432, 4.6, "甜,咸", 0),
            ("炸薯条(大)", "外脆里软，金黄诱人", 9.9, 12.0, "🍟", 2, 1890, 4.7, "", 0),

            # 日韩料理 (category_id=3)
            ("三文鱼刺身", "挪威深海三文鱼，新鲜直达", 48.0, 60.0, "🍣", 3, 320, 4.9, "生食", 0),
            ("招牌豚骨拉面", "12小时熬制浓白汤底", 28.0, 35.0, "🍜", 3, 1100, 4.8, "招牌,热", 1),
            ("鳗鱼寿司(8粒)", "蒲烧鳗鱼，秘制酱汁", 32.0, 42.0, "🍙", 3, 540, 4.7, "招牌", 0),

            # 中式快餐 (category_id=4)
            ("红烧牛肉面", "手工拉面，慢炖牛腩", 22.0, 28.0, "🍜", 4, 1450, 4.7, "招牌", 0),
            ("宫保鸡丁盖饭", "川味经典，下饭神器", 18.0, 24.0, "🍚", 4, 980, 4.6, "辣", 0),
            ("番茄牛腩煲", "酸甜浓郁，软烂入味", 32.0, 42.0, "🍲", 4, 540, 4.8, "酸甜", 0),

            # 奶茶饮品 (category_id=5)
            ("杨枝甘露", "芒果西柚椰浆，港式经典", 16.0, 22.0, "🥭", 5, 1230, 4.9, "招牌", 1),
            ("珍珠奶茶(大杯)", "黑糖珍珠，香浓奶茶", 12.0, 16.0, "🧋", 5, 2560, 4.8, "招牌", 1),
            ("柠檬养乐多", "清爽解腻，益生菌", 10.0, 14.0, "🍋", 5, 760, 4.6, "清爽", 0),

            # 甜品蛋糕 (category_id=6)
            ("提拉米苏(切片)", "意式经典，入口即化", 22.0, 28.0, "🍰", 6, 320, 4.8, "招牌", 0),
            ("巧克力熔岩蛋糕", "爆浆流心，浓郁可可", 18.0, 24.0, "🍰", 6, 480, 4.7, "甜", 0),
            ("草莓千层", "新鲜草莓，法式千层", 26.0, 35.0, "🍰", 6, 290, 4.9, "甜", 0),

            # 夜宵小吃 (category_id=7)
            ("麻辣小龙虾(一斤)", "鲜香麻辣，停不下来", 68.0, 88.0, "🦞", 7, 890, 4.8, "辣,招牌", 1),
            ("烤肉拼盘(10串)", "炭火现烤，五种口味", 35.0, 48.0, "🍢", 7, 1230, 4.7, "咸,辣", 0),
            ("蒜蓉烤生蚝(6只)", "新鲜肥美，蒜香四溢", 38.0, 50.0, "🦪", 7, 560, 4.8, "蒜香", 0),

            # 水果沙拉 (category_id=8)
            ("鲜切水果拼盘", "5种时令水果，新鲜直达", 18.0, 25.0, "🍎", 8, 760, 4.7, "清爽", 0),
            ("牛油果沙拉", "墨西哥牛油果，健康轻食", 22.0, 30.0, "🥑", 8, 320, 4.8, "健康", 0),
        ]
        cur.executemany(
            """INSERT INTO foods
               (name, description, price, original_price, image, category_id, sales, rating, tags, is_recommend)
               VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)""",
            foods,
        )

        # 默认地址
        cur.execute(
            "INSERT INTO addresses (user_id, receiver, phone, province, city, district, detail, is_default) "
            "VALUES (1, '测试用户', '13800138000', '北京市', '北京市', '朝阳区', '建国路88号SOHO现代城1号楼1单元102室', 1)"
        )

    print("[OK] 演示数据已插入")
