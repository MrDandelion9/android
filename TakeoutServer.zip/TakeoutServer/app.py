"""
美味达外卖平台 - 后端 API
启动: python app.py
默认端口: 5000
Android 端 Base URL: http://10.0.2.2:5000 (模拟器) / http://192.168.x.x:5000 (真机)
"""
import sys
import os
import uuid
import secrets
from datetime import datetime
from flask import Flask, request, jsonify, g
from flask_cors import CORS

from db import init_db, seed_data, get_db
from ai_recommend import recommend_for_user

# ---------- App 初始化 ----------
app = Flask(__name__)
CORS(app)  # 允许跨域

# 简易内存 token 池: {token: user_id}
_TOKENS = {}


# ---------- 重新定义 get_db 为函数（返回连接） ----------
def _conn():
    """直接获取一个 SQLite 连接（非上下文管理器版本）"""
    import sqlite3
    conn = sqlite3.connect(os.path.join(os.path.dirname(__file__), "takeout.db"))
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA foreign_keys = ON")
    return conn


# ---------- 工具函数 ----------
def ok(data=None, msg="success"):
    return jsonify({"code": 0, "msg": msg, "data": data})


def fail(msg, code=1):
    return jsonify({"code": code, "msg": msg, "data": None})


def make_token(user_id):
    token = secrets.token_hex(16)
    _TOKENS[token] = user_id
    return token


def auth_required(func):
    from functools import wraps

    @wraps(func)
    def wrapper(*args, **kwargs):
        token = request.headers.get("Authorization", "").replace("Bearer ", "")
        user_id = _TOKENS.get(token)
        if not user_id:
            return fail("未登录或登录已过期", 401)
        g.user_id = user_id
        return func(*args, **kwargs)
    return wrapper


def row_to_dict(row):
    return dict(row) if row else None


# ---------- 启动时初始化数据库 ----------
with app.app_context():
    init_db()
    seed_data()


# ==================== 接口 ====================

# ---------- 1. 用户登录 ----------
@app.post("/api/login")
def login():
    data = request.get_json(silent=True) or {}
    username = (data.get("username") or "").strip()
    password = (data.get("password") or "").strip()

    if not username or not password:
        return fail("账号或密码不能为空")

    conn = _conn()
    try:
        cur = conn.cursor()
        cur.execute(
            "SELECT id, username, nickname, phone FROM users WHERE username = ? AND password = ?",
            (username, password),
        )
        user = cur.fetchone()
    finally:
        conn.close()

    if not user:
        return fail("账号或密码错误")

    token = make_token(user["id"])
    return ok({
        "token": token,
        "user": {
            "id": user["id"],
            "username": user["username"],
            "nickname": user["nickname"],
            "phone": user["phone"],
        }
    })


# ---------- 2. 用户注册 ----------
@app.post("/api/register")
def register():
    data = request.get_json(silent=True) or {}
    username = (data.get("username") or "").strip()
    password = (data.get("password") or "").strip()
    nickname = (data.get("nickname") or "新用户").strip()

    if not username or not password:
        return fail("账号或密码不能为空")
    if len(password) < 6:
        return fail("密码长度至少 6 位")

    conn = _conn()
    try:
        cur = conn.cursor()
        cur.execute("SELECT id FROM users WHERE username = ?", (username,))
        if cur.fetchone():
            return fail("账号已存在")
        cur.execute(
            "INSERT INTO users (username, password, nickname) VALUES (?, ?, ?)",
            (username, password, nickname),
        )
        conn.commit()
        new_id = cur.lastrowid
    finally:
        conn.close()

    return ok({"id": new_id, "username": username}, "注册成功")


# ---------- 3. 首页轮播图 ----------
@app.get("/api/banners")
def banners():
    conn = _conn()
    try:
        cur = conn.cursor()
        cur.execute("SELECT * FROM banners ORDER BY sort_order ASC")
        rows = [row_to_dict(r) for r in cur.fetchall()]
    finally:
        conn.close()
    return ok(rows)


# ---------- 4. 分类列表 ----------
@app.get("/api/categories")
def categories():
    conn = _conn()
    try:
        cur = conn.cursor()
        cur.execute("SELECT * FROM categories ORDER BY sort_order ASC")
        rows = [row_to_dict(r) for r in cur.fetchall()]
    finally:
        conn.close()
    return ok(rows)


# ---------- 5. 菜品列表 ----------
@app.get("/api/foods")
def food_list():
    category_id = request.args.get("category_id", type=int)
    keyword = (request.args.get("keyword") or "").strip()
    recommend_only = request.args.get("recommend", "0") == "1"

    sql = "SELECT * FROM foods WHERE 1=1"
    params = []
    if category_id:
        sql += " AND category_id = ?"
        params.append(category_id)
    if keyword:
        sql += " AND (name LIKE ? OR description LIKE ? OR tags LIKE ?)"
        params.extend([f"%{keyword}%"] * 3)
    if recommend_only:
        sql += " AND is_recommend = 1"
    sql += " ORDER BY sales DESC"

    conn = _conn()
    try:
        cur = conn.cursor()
        cur.execute(sql, params)
        rows = [row_to_dict(r) for r in cur.fetchall()]
    finally:
        conn.close()
    return ok(rows)


# ---------- 6. 菜品详情 ----------
@app.get("/api/foods/<int:food_id>")
def food_detail(food_id):
    conn = _conn()
    try:
        cur = conn.cursor()
        cur.execute("SELECT * FROM foods WHERE id = ?", (food_id,))
        food = cur.fetchone()
    finally:
        conn.close()
    if not food:
        return fail("菜品不存在", 404)
    return ok(row_to_dict(food))


# ---------- 7. AI 推荐 ----------
@app.get("/api/recommend")
@auth_required
def recommend():
    limit = request.args.get("limit", default=6, type=int)
    reason, foods = recommend_for_user(g.user_id, limit=limit)

    conn = _conn()
    try:
        cur = conn.cursor()
        for f in foods:
            cur.execute(
                "INSERT INTO user_history (user_id, food_id, action) VALUES (?, ?, ?)",
                (g.user_id, f["id"], "view"),
            )
        conn.commit()
    finally:
        conn.close()

    return ok({"reason": reason, "foods": foods})


# ---------- 8. 收货地址 ----------
@app.get("/api/addresses")
@auth_required
def list_addresses():
    conn = _conn()
    try:
        cur = conn.cursor()
        cur.execute(
            "SELECT * FROM addresses WHERE user_id = ? ORDER BY is_default DESC, id DESC",
            (g.user_id,),
        )
        rows = [row_to_dict(r) for r in cur.fetchall()]
    finally:
        conn.close()
    return ok(rows)


@app.post("/api/addresses")
@auth_required
def add_address():
    data = request.get_json(silent=True) or {}
    required = ("receiver", "phone", "detail")
    if not all(data.get(k) for k in required):
        return fail("收件人/电话/详细地址不能为空")

    conn = _conn()
    try:
        cur = conn.cursor()
        if data.get("is_default"):
            cur.execute("UPDATE addresses SET is_default = 0 WHERE user_id = ?", (g.user_id,))
        cur.execute(
            """INSERT INTO addresses
               (user_id, receiver, phone, province, city, district, detail, is_default)
               VALUES (?, ?, ?, ?, ?, ?, ?, ?)""",
            (
                g.user_id,
                data["receiver"],
                data["phone"],
                data.get("province", ""),
                data.get("city", ""),
                data.get("district", ""),
                data["detail"],
                1 if data.get("is_default") else 0,
            ),
        )
        conn.commit()
        new_id = cur.lastrowid
    finally:
        conn.close()
    return ok({"id": new_id}, "地址保存成功")


# ---------- 9. 创建订单 ----------
@app.post("/api/orders")
@auth_required
def create_order():
    data = request.get_json(silent=True) or {}
    address_id = data.get("address_id")
    payment_method = data.get("payment_method", "wechat")
    remark = data.get("remark", "")
    items = data.get("items", [])

    if not items:
        return fail("购物车为空")
    if not address_id:
        return fail("请选择收货地址")

    conn = _conn()
    try:
        cur = conn.cursor()
        total = 0.0
        item_rows = []
        for it in items:
            food_id = it.get("food_id")
            qty = int(it.get("quantity", 0))
            if qty <= 0:
                continue
            cur.execute("SELECT id, name, price, sales FROM foods WHERE id = ?", (food_id,))
            f = cur.fetchone()
            if not f:
                return fail(f"菜品 {food_id} 不存在")
            total += f["price"] * qty
            item_rows.append({
                "food_id": f["id"],
                "name": f["name"],
                "price": f["price"],
                "quantity": qty,
            })
            cur.execute("UPDATE foods SET sales = sales + ? WHERE id = ?", (qty, f["id"]))
            cur.execute(
                "INSERT INTO user_history (user_id, food_id, action) VALUES (?, ?, 'buy')",
                (g.user_id, f["id"]),
            )

        delivery_fee = 5.0 if total < 30 else 0.0
        total += delivery_fee

        order_no = datetime.now().strftime("%Y%m%d%H%M%S") + uuid.uuid4().hex[:6].upper()
        cur.execute(
            """INSERT INTO orders
               (order_no, user_id, address_id, total_price, status, payment_method, remark)
               VALUES (?, ?, ?, ?, 'paid', ?, ?)""",
            (order_no, g.user_id, address_id, total, payment_method, remark),
        )
        order_id = cur.lastrowid

        for it in item_rows:
            cur.execute(
                """INSERT INTO order_items (order_id, food_id, name, price, quantity)
                   VALUES (?, ?, ?, ?, ?)""",
                (order_id, it["food_id"], it["name"], it["price"], it["quantity"]),
            )
        conn.commit()
    finally:
        conn.close()

    return ok({
        "order_id": order_id,
        "order_no": order_no,
        "total_price": round(total, 2),
        "delivery_fee": delivery_fee,
        "items": item_rows,
        "payment_method": payment_method,
        "status": "paid",
    }, "下单成功，已为您派单")


# ---------- 10. 订单列表 ----------
@app.get("/api/orders")
@auth_required
def list_orders():
    conn = _conn()
    try:
        cur = conn.cursor()
        cur.execute(
            "SELECT * FROM orders WHERE user_id = ? ORDER BY created_at DESC",
            (g.user_id,),
        )
        orders = []
        for r in cur.fetchall():
            order = row_to_dict(r)
            cur.execute("SELECT * FROM order_items WHERE order_id = ?", (order["id"],))
            order["items"] = [row_to_dict(x) for x in cur.fetchall()]
            orders.append(order)
    finally:
        conn.close()
    return ok(orders)


# ---------- 11. 健康检查 ----------
@app.get("/api/health")
def health():
    return ok({"status": "ok", "time": datetime.now().isoformat()})


# ---------- 入口 ----------
if __name__ == "__main__":
    if sys.stdout.encoding and sys.stdout.encoding.lower() != "utf-8":
        try:
            sys.stdout.reconfigure(encoding="utf-8")
        except Exception:
            pass
    print("=" * 50)
    print("[Takeout] 美味达外卖平台 - 后端启动")
    print("=" * 50)
    print("API 地址: http://127.0.0.1:5000")
    print("模拟器访问: http://10.0.2.2:5000")
    print("测试账号: test@test.com / 123456")
    print("=" * 50)
    app.run(host="0.0.0.0", port=5000, debug=False)
