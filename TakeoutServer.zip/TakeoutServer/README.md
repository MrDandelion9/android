# 美味达外卖平台 - 后端

基于 Flask + SQLite 的轻量级外卖平台后端。

## 🚀 快速启动

```bash
# 1. 安装依赖
pip install -r requirements.txt

# 2. 启动服务（首次启动会自动建库建表 + 插入演示数据）
python app.py
```

启动后访问 http://127.0.0.1:5000

## 📡 API 列表

| 方法 | 路径 | 说明 | 是否需要登录 |
|------|------|------|--------------|
| POST | `/api/login` | 登录 | ❌ |
| POST | `/api/register` | 注册 | ❌ |
| GET | `/api/health` | 健康检查 | ❌ |
| GET | `/api/banners` | 轮播图 | ❌ |
| GET | `/api/categories` | 分类列表 | ❌ |
| GET | `/api/foods` | 菜品列表（支持 `category_id`、`keyword`、`recommend`） | ❌ |
| GET | `/api/foods/<id>` | 菜品详情 | ❌ |
| GET | `/api/recommend` | AI 推荐 | ✅ |
| GET | `/api/addresses` | 地址列表 | ✅ |
| POST | `/api/addresses` | 新增地址 | ✅ |
| POST | `/api/orders` | 创建订单 | ✅ |
| GET | `/api/orders` | 订单列表 | ✅ |

登录后的接口请在 Header 携带：
```
Authorization: Bearer <token>
```

## 🧪 测试账号

| 账号 | 密码 | 备注 |
|------|------|------|
| `test@test.com` | `123456` | 默认 |
| `13800138000` | `123456` | 手机号 |
| `admin` | `admin` | 管理员 |

## 🔌 Android 端连接

| 场景 | Base URL |
|------|----------|
| **模拟器访问宿主机** | `http://10.0.2.2:5000` |
| **真机（同局域网）** | `http://<电脑内网IP>:5000` |
| **同一台电脑浏览器调试** | `http://127.0.0.1:5000` |

> 模拟器里 `localhost` / `127.0.0.1` 指向模拟器自身，要用 `10.0.2.2` 才能访问宿主机。

## 📦 项目结构

```
TakeoutServer/
├── app.py              # 主程序，路由 + 业务逻辑
├── db.py               # 数据库初始化 + 演示数据
├── ai_recommend.py     # AI 推荐引擎（本地规则）
├── requirements.txt    # 依赖
├── takeout.db          # SQLite 数据库（首次运行自动创建）
└── README.md
```

## 🗄️ 数据库表

- `users` - 用户
- `banners` - 轮播图
- `categories` - 分类
- `foods` - 菜品
- `addresses` - 收货地址
- `orders` - 订单
- `order_items` - 订单详情
- `user_history` - 用户行为历史（用于推荐）

## 🤖 AI 推荐策略

按优先级综合打分：
1. **时段匹配**（早餐/午餐/下午茶/晚餐/夜宵）+30 分
2. **用户偏好分类**（基于购买历史）+40 分
3. **是否招牌推荐** +15 分
4. **销量**（每 200 销量 +1 分，上限 20）
5. **评分**（高于 4.0 每加 0.1 +1 分）

## 🔄 重置数据

删除 `takeout.db` 文件后重新启动 `app.py` 即可。
