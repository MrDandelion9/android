"""
本地规则推荐引擎

策略（按优先级）：
1. 时间维度：
   - 早餐（06-10）：轻食、饮品
   - 午餐（11-13）：快餐、主食
   - 下午茶（14-17）：甜品、奶茶
   - 晚餐（18-21）：正餐
   - 夜宵（22-05）：夜宵小吃
2. 用户历史：优先推荐与已购同类/同标签的菜
3. 标签匹配：根据传入的偏好标签
4. 热门补充：从销量最高里补充
"""
import os
import sqlite3
from datetime import datetime

DB_PATH = os.path.join(os.path.dirname(__file__), "takeout.db")


def _conn():
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    return conn


def _time_segment():
    h = datetime.now().hour
    if 6 <= h < 10:
        return ["早餐", "清爽"]
    if 11 <= h < 14:
        return ["招牌", "主食"]
    if 14 <= h < 17:
        return ["甜", "清爽"]
    if 18 <= h < 22:
        return ["招牌", "热"]
    return ["辣", "夜宵", "咸"]


def _parse_tags(tags_str):
    if not tags_str:
        return set()
    return {t.strip() for t in tags_str.split(",") if t.strip()}


def recommend_for_user(user_id, limit=6):
    """为用户生成推荐"""
    conn = _conn()
    try:
        cur = conn.cursor()

        # 用户购买历史中频次最高的分类
        cur.execute(
            """
            SELECT f.category_id, COUNT(*) as cnt
            FROM user_history h JOIN foods f ON h.food_id = f.id
            WHERE h.user_id = ? AND h.action = 'buy'
            GROUP BY f.category_id
            ORDER BY cnt DESC
            LIMIT 1
            """,
            (user_id,),
        )
        row = cur.fetchone()
        fav_category_id = row["category_id"] if row else None

        time_tags = set(_time_segment())

        cur.execute("SELECT * FROM foods")
        all_foods = [dict(r) for r in cur.fetchall()]

        # 取用户最爱的分类名
        fav_category_name = None
        if fav_category_id:
            cur.execute("SELECT name FROM categories WHERE id = ?", (fav_category_id,))
            r = cur.fetchone()
            if r:
                fav_category_name = r["name"]
    finally:
        conn.close()

    def score(food):
        s = 0
        tags = _parse_tags(food["tags"])
        if tags & time_tags:
            s += 30
        if fav_category_id and food["category_id"] == fav_category_id:
            s += 40
        if food["is_recommend"]:
            s += 15
        s += min(food["sales"] / 200, 20)
        s += (food["rating"] - 4.0) * 10
        return s

    scored = sorted(all_foods, key=score, reverse=True)
    top = scored[:limit]

    hour = datetime.now().hour
    if 6 <= hour < 10:
        reason = "早安，开启元气满满的一天"
    elif 11 <= hour < 14:
        reason = "午餐时间到啦，看看大家都在吃"
    elif 14 <= hour < 17:
        reason = "下午茶时光，犒劳一下自己"
    elif 18 <= hour < 22:
        reason = "晚餐已为您准备好"
    else:
        reason = "深夜食堂，美味不打烊"

    if fav_category_name:
        reason += f"，根据您的口味推荐【{fav_category_name}】系列"

    return reason, top
